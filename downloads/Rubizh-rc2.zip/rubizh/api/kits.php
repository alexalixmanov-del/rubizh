<?php
declare(strict_types=1);
require_once __DIR__.'/../shop/kit-data.php';
function sync_kits(PDO $db,array $input): void {
 pimLegacyWrite($db,function()use($db,$input){pimSyncLegacyKits($db,$input);});
}
function pimSyncLegacyKits(PDO $db,array $input): void {
 if(!$db->inTransaction()){sync_kits($db,$input);return;}
 shopPricingCatalogVersion($db,true);
 pimRequireLegacySync();
 if(count($input)>3)throw new RuntimeException('Максимум три готові комплекти');$clean=[];$ids=[];$seen=[];
 foreach($input as $b){if(!is_array($b)||!in_array($b['id']??'', ['b1','b2','b3'],true)||isset($seen[$b['id']]))throw new RuntimeException('Невірний ідентифікатор комплекту');$seen[$b['id']]=true;$name=trim((string)($b['name']??''));$note=trim((string)($b['note']??''));$items=$b['items']??[];if($name===''||mb_strlen($name)>24||mb_strlen($note)>80||!is_array($items)||count($items)<2||count($items)>8)throw new RuntimeException('Перевірте назву та склад комплекту');$rows=[];foreach($items as $it){if(is_string($it))$it=['product_id'=>$it,'color'=>''];if(!is_array($it)||!is_string($it['product_id']??null)||strlen($it['product_id'])>64||$it['product_id']===''||isset($ids[$it['product_id']]))throw new RuntimeException('Товари не повинні повторюватися між комплектами');$ids[$it['product_id']]=true;$color=(string)($it['color']??'');if(mb_strlen($color)>80)throw new RuntimeException('Невірний колір');$qty=shopQuantity($it['qty']??1,'piece');$sku=$it['sku']??null;if($sku!==null&&(!is_string($sku)||$sku===''||strlen($sku)>64))throw new RuntimeException('Невірний SKU комплекту');$rows[]=['product_id'=>$it['product_id'],'color'=>$color,'role'=>(string)($it['role']??''),'qty'=>$qty]+($sku===null?[]:['sku'=>$sku]);}$clean[]=['id'=>$b['id'],'name'=>$name,'note'=>$note,'items'=>$rows];}
 pimAssertLegacyModels($db,array_keys($ids));
 $products=array_column(shopProductsByIds($db,array_keys($ids)),null,'id');foreach($clean as $b)foreach($b['items'] as $it){$p=$products[$it['product_id']]??null;if(!$p)throw new RuntimeException('Товар комплекту недоступний');if(isset($it['sku'])&&!in_array($it['sku'],array_column($p['variants'],'sku'),true))throw new RuntimeException('SKU не належить товару комплекту');}
 foreach($clean as $b){$roles=array_column($b['items'],'role');if(array_filter($roles)){$req=['b1'=>['ubacs','pants','magazine'],'b2'=>['protection','ubacs','ifak'],'b3'=>['thermal','fleece','gloves']][$b['id']];if(count(array_intersect($roles,$req))!==3)throw new RuntimeException('Немає обов’язкових ролей комплекту');foreach($b['items'] as $it){$p=$products[$it['product_id']]??null;if(!$p)throw new RuntimeException('Товар комплекту недоступний');if(isset($it['sku'])&&!in_array($it['sku'],array_column($p['variants'],'sku'),true))throw new RuntimeException('SKU не належить товару комплекту');if($p&&$it['role']!==''&&shopKitRole($p)!==$it['role'])throw new RuntimeException('Товар не відповідає ролі');if($p&&$it['role']==='protection'&&!shopKitWithPlates($p)&&!in_array('plate',$roles,true))throw new RuntimeException('До плитоноски потрібно додати плити');}}}
 $db->prepare("INSERT INTO meta(k,v) VALUES('site_kits',?) ON DUPLICATE KEY UPDATE v=VALUES(v)")->execute([json_encode($clean,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
}
